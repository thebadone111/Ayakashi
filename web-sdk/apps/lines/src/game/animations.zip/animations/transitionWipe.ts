/**
 * Ayakashi — screen transition ink wipe (replaces the `transition` Spine).
 *
 * A wall of sumi ink with a living, wavy leading edge sweeps across the
 * screen, fully covers it (scene swap happens here), holds a beat, then
 * sweeps off the other side. Mist particles ride the edge; a faint foxfire
 * rim lights the wave front.
 *
 * Wiring (Tom) — Transition.svelte's `transition` emitter event is awaited
 * by the freeSpinTrigger/freeSpinEnd handlers, with the scene swap happening
 * mid-transition. Map it 1:1:
 *
 *   const wipe = new TransitionWipe({ app, parent: topLayer, width, height });
 *   // on 'transition' (broadcastAsync):
 *   await wipe.play({ onCovered: () => { ...swap background/board mood... } });
 *   wipe.destroy(); // unmount
 */

import { Application, Container, Graphics, Ticker } from 'pixi.js';

import {
	PALETTE,
	TweenRunner,
	ParticlePool,
	easings,
	delay,
} from './fx';

export interface TransitionWipeOptions {
	app: Application;
	parent: Container;
	width?: number;
	height?: number;
}

export class TransitionWipe {
	private app: Application;
	private parent: Container;
	private tweens: TweenRunner;
	private particles: ParticlePool;
	private width: number;
	private height: number;
	private root: Container | null = null;
	private waveTick: ((t: Ticker) => void) | null = null;
	private playing = false;

	constructor(opts: TransitionWipeOptions) {
		this.app = opts.app;
		this.parent = opts.parent;
		this.width = opts.width ?? opts.app.screen.width;
		this.height = opts.height ?? opts.app.screen.height;
		this.tweens = new TweenRunner(opts.app.ticker);
		this.particles = new ParticlePool(opts.app.ticker, opts.app.renderer, 120);
	}

	/**
	 * Run the full wipe. `onCovered` fires when the screen is fully hidden —
	 * do the scene/mood swap there. Resolves when the wipe has fully receded.
	 */
	async play(opts: { onCovered?: () => void; holdMs?: number } = {}): Promise<void> {
		if (this.playing) return;
		this.playing = true;

		const W = this.width;
		const H = this.height;
		const root = new Container();
		this.root = root;
		this.parent.addChild(root);
		root.addChild(this.particles.container);

		// the ink wall: a Graphics redrawn each frame with a wavy leading edge.
		// state.front = x position of the wave front; covers everything left of it.
		const ink = new Graphics();
		root.addChild(ink);
		const state = { front: -W * 0.25 }; // start fully off-screen left
		const SEGMENTS = 24;
		const phase = Math.random() * 10;
		let elapsed = 0;

		const draw = () => {
			ink.clear();
			const amp = W * 0.06;
			// leading edge points top→bottom
			const pts: number[] = [];
			for (let i = 0; i <= SEGMENTS; i++) {
				const yy = (H * i) / SEGMENTS;
				const wave =
					Math.sin(i * 0.7 + phase + elapsed * 0.004) * amp * 0.6 +
					Math.sin(i * 1.9 + phase * 2 + elapsed * 0.007) * amp * 0.4;
				pts.push(state.front + wave, yy);
			}
			// closed polygon covering everything left of the edge
			const poly = [-W * 0.5, 0, ...pts, -W * 0.5, H];
			ink.poly(poly).fill({ color: PALETTE.INK });
			// foxfire rim on the wave front
			ink.moveTo(pts[0], pts[1]);
			for (let i = 1; i <= SEGMENTS; i++) ink.lineTo(pts[i * 2], pts[i * 2 + 1]);
			ink.stroke({ color: PALETTE.FOXFIRE, width: 3, alpha: 0.5 });
		};

		// edge mist particles + frame redraw
		let mistAcc = 0;
		this.waveTick = (ticker: Ticker) => {
			elapsed += ticker.deltaMS;
			draw();
			mistAcc += ticker.deltaMS;
			if (mistAcc >= 70 && state.front > 0 && state.front < W * 1.2) {
				mistAcc = 0;
				this.particles.emit({
					x: state.front,
					y: Math.random() * H,
					count: 2,
					speed: [40, 140],
					angle: [-0.4, 0.4], // pushed forward off the wave
					drag: 0.4,
					life: [400, 900],
					scaleStart: [0.6, 1.4],
					scaleEnd: 1.8,
					alphaStart: 0.35,
					tints: [0x2a2a38, 0x3a3a4a, PALETTE.SPIRIT],
					blendMode: 'normal',
				});
			}
		};
		this.app.ticker.add(this.waveTick);

		// sweep in — cover the screen
		await this.tweens.to(state, { front: W * 1.3 }, { duration: 650, ease: easings.cubicInOut });

		// fully covered — swap scenes
		opts.onCovered?.();
		await delay(opts.holdMs ?? 180);

		// sweep out — same direction (wave exits right, screen revealed behind it)
		// redraw as a right-side wall receding: invert by tweening a second front
		const out = { front: -W * 0.25 };
		const drawOut = () => {
			ink.clear();
			const amp = W * 0.06;
			const pts: number[] = [];
			for (let i = 0; i <= SEGMENTS; i++) {
				const yy = (H * i) / SEGMENTS;
				const wave =
					Math.sin(i * 0.7 + phase + elapsed * 0.004) * amp * 0.6 +
					Math.sin(i * 1.9 + phase * 2 + elapsed * 0.007) * amp * 0.4;
				pts.push(out.front + wave, yy);
			}
			const poly = [...pts, W * 1.5, H, W * 1.5, 0];
			ink.poly(poly).fill({ color: PALETTE.INK });
			ink.moveTo(pts[0], pts[1]);
			for (let i = 1; i <= SEGMENTS; i++) ink.lineTo(pts[i * 2], pts[i * 2 + 1]);
			ink.stroke({ color: PALETTE.FOXFIRE, width: 3, alpha: 0.5 });
		};
		// swap the per-frame draw to the receding wall
		this.app.ticker.remove(this.waveTick);
		this.waveTick = (ticker: Ticker) => {
			elapsed += ticker.deltaMS;
			drawOut();
		};
		this.app.ticker.add(this.waveTick);

		await this.tweens.to(out, { front: W * 1.3 }, { duration: 650, ease: easings.cubicInOut });

		this.teardownScene();
		this.playing = false;
	}

	private teardownScene() {
		if (this.waveTick) {
			this.app.ticker.remove(this.waveTick);
			this.waveTick = null;
		}
		if (this.root) {
			this.root.removeChild(this.particles.container);
			this.root.destroy({ children: true });
			this.root = null;
		}
		this.particles.clear();
	}

	destroy() {
		this.teardownScene();
		this.tweens.destroy();
		this.particles.destroy();
		this.playing = false;
	}
}
