/**
 * Ayakashi — background ambient animation.
 *
 * Drives the four finalized background layers from art/finals as a living
 * scene (PixiJS replacement for the reference foregroundAnimation Spine rig):
 *
 *   bg_bg.png     — base painting (blend: normal)        → slow 1.5% zoom breath
 *   bg_fg.png     — decorative trim (blend: screen)      → static, masks edges
 *   bg_effect.png — glow/light pass (blend: add)         → organic flicker
 *   bg_mist.png   — atmosphere (blend: normal, 50%)      → two copies drifting
 *                                                          opposite ways, seamless
 *   + sparse ember motes rising through the scene.
 *
 * `setMood('base' | 'freespin')` crossfades the scene tint — free spins push
 * the palette toward spirit-purple and raise ember density.
 *
 * Wiring (Tom) — in Background.svelte:
 *
 *   const bg = new BackgroundAmbient({
 *     app, parent: backgroundLayer,
 *     textures: { base: bgBgTex, trim: bgFgTex, effect: bgEffectTex, mist: bgMistTex },
 *     width, height,
 *   });
 *   bg.setMood('freespin'); // on freeSpinTrigger
 *   bg.setMood('base');     // on freeSpinEnd
 *   bg.resize(w, h);        // on canvas resize
 *   bg.destroy();           // on unmount
 */

import { Application, Container, Sprite, Texture, Ticker } from 'pixi.js';

import { PALETTE, TweenRunner, ParticlePool, easings } from './fx';

export interface BackgroundAmbientOptions {
	app: Application;
	parent: Container;
	textures: {
		base: Texture;
		trim?: Texture;
		effect?: Texture;
		mist?: Texture;
	};
	width: number;
	height: number;
}

type Mood = 'base' | 'freespin';

const MOOD_TINTS: Record<Mood, { base: number; effect: number; emberEveryMs: number }> = {
	base: { base: 0xffffff, effect: 0xffffff, emberEveryMs: 480 },
	freespin: { base: 0xcdb8e8, effect: 0xb794e6, emberEveryMs: 220 },
};

export class BackgroundAmbient {
	private app: Application;
	private parent: Container;
	private root: Container;
	private tweens: TweenRunner;
	private particles: ParticlePool;
	private width: number;
	private height: number;

	private base: Sprite;
	private trim: Sprite | null = null;
	private effect: Sprite | null = null;
	private mistA: Sprite | null = null;
	private mistB: Sprite | null = null;

	private mood: Mood = 'base';
	private elapsed = 0;
	private emberAccumulator = 0;
	private tick = (ticker: Ticker) => this.update(ticker.deltaMS);

	constructor(opts: BackgroundAmbientOptions) {
		this.app = opts.app;
		this.parent = opts.parent;
		this.width = opts.width;
		this.height = opts.height;
		this.tweens = new TweenRunner(opts.app.ticker);
		this.particles = new ParticlePool(opts.app.ticker, opts.app.renderer, 60);

		this.root = new Container();
		this.parent.addChild(this.root);

		// base painting — anchored centre so the zoom breath stays centred
		this.base = new Sprite(opts.textures.base);
		this.base.anchor.set(0.5);
		this.root.addChild(this.base);

		// mist layers — two copies drifting opposite directions, wrapped
		if (opts.textures.mist) {
			this.mistA = new Sprite(opts.textures.mist);
			this.mistB = new Sprite(opts.textures.mist);
			for (const m of [this.mistA, this.mistB]) {
				m.anchor.set(0.5);
				m.alpha = 0.5;
				this.root.addChild(m);
			}
			this.mistB.scale.x = -1; // mirrored so the seam never reads as a repeat
			this.mistB.alpha = 0.35;
		}

		// embers between mist and effect pass
		this.root.addChild(this.particles.container);

		// additive glow pass — flickers
		if (opts.textures.effect) {
			this.effect = new Sprite(opts.textures.effect);
			this.effect.anchor.set(0.5);
			this.effect.blendMode = 'add';
			this.effect.alpha = 0.85;
			this.root.addChild(this.effect);
		}

		// screen-blend trim on top
		if (opts.textures.trim) {
			this.trim = new Sprite(opts.textures.trim);
			this.trim.anchor.set(0.5);
			this.trim.blendMode = 'screen';
			this.root.addChild(this.trim);
		}

		this.layout();
		this.app.ticker.add(this.tick);
	}

	/** Crossfade scene mood (free spins = spirit-purple, denser embers). */
	setMood(mood: Mood) {
		if (mood === this.mood) return;
		this.mood = mood;
		const tints = MOOD_TINTS[mood];
		// tween tint via RGB channels
		const lerpTint = (sprite: Sprite | null, toTint: number) => {
			if (!sprite) return;
			const from = typeof sprite.tint === 'number' ? sprite.tint : 0xffffff;
			const state = { t: 0 };
			const fr = (from >> 16) & 0xff, fg = (from >> 8) & 0xff, fb = from & 0xff;
			const tr = (toTint >> 16) & 0xff, tg = (toTint >> 8) & 0xff, tb = toTint & 0xff;
			void this.tweens.to(state, { t: 1 }, {
				duration: 900,
				ease: easings.sineInOut,
				onUpdate: () => {
					const r = Math.round(fr + (tr - fr) * state.t);
					const g = Math.round(fg + (tg - fg) * state.t);
					const b = Math.round(fb + (tb - fb) * state.t);
					sprite.tint = (r << 16) | (g << 8) | b;
				},
			});
		};
		lerpTint(this.base, tints.base);
		lerpTint(this.effect, tints.effect);
	}

	resize(width: number, height: number) {
		this.width = width;
		this.height = height;
		this.layout();
	}

	private layout() {
		const cx = this.width / 2;
		const cy = this.height / 2;
		const cover = (sprite: Sprite, extra = 1) => {
			const scale = Math.max(this.width / sprite.texture.width, this.height / sprite.texture.height) * extra;
			sprite.scale.set(scale * Math.sign(sprite.scale.x || 1), scale);
			sprite.position.set(cx, cy);
		};
		cover(this.base, 1.04); // slight over-scan leaves room for the zoom breath
		if (this.effect) cover(this.effect, 1.04);
		if (this.trim) cover(this.trim, 1);
		if (this.mistA) cover(this.mistA, 1.3); // wide over-scan for drift travel
		if (this.mistB) cover(this.mistB, 1.3);
	}

	private update(deltaMS: number) {
		this.elapsed += deltaMS;
		const t = this.elapsed / 1000;
		const cx = this.width / 2;
		const cy = this.height / 2;

		// base zoom breath — 14 s period, ±1.5%
		const breath = 1 + Math.sin((t / 14) * Math.PI * 2) * 0.015;
		const baseCover = Math.max(this.width / this.base.texture.width, this.height / this.base.texture.height) * 1.04;
		this.base.scale.set(baseCover * breath);

		// mist drift — opposing sine paths, never leaves the over-scan
		const driftRange = this.width * 0.06;
		if (this.mistA) {
			this.mistA.position.set(
				cx + Math.sin(t / 23) * driftRange,
				cy + Math.sin(t / 31) * driftRange * 0.3,
			);
		}
		if (this.mistB) {
			this.mistB.position.set(
				cx - Math.sin(t / 19 + 1.7) * driftRange,
				cy + Math.cos(t / 27) * driftRange * 0.25,
			);
		}

		// effect flicker — layered sines read as organic firelight
		if (this.effect) {
			this.effect.alpha =
				0.72 + Math.sin(t * 1.9) * 0.06 + Math.sin(t * 5.3 + 2) * 0.04 + Math.sin(t * 11.7) * 0.02;
		}

		// sparse rising embers
		this.emberAccumulator += deltaMS;
		const every = MOOD_TINTS[this.mood].emberEveryMs;
		if (this.emberAccumulator >= every) {
			this.emberAccumulator = 0;
			const tints =
				this.mood === 'freespin'
					? [PALETTE.SPIRIT, PALETTE.FOXFIRE, PALETTE.EMBER]
					: [PALETTE.EMBER, PALETTE.EMBER_HI];
			this.particles.emit({
				x: Math.random() * this.width,
				y: this.height + 10,
				count: 1,
				speed: [15, 45],
				angle: [-Math.PI * 0.58, -Math.PI * 0.42],
				life: [5000, 9000],
				scaleStart: [0.15, 0.45],
				scaleEnd: 0,
				alphaStart: 0.8,
				tints,
			});
		}
	}

	destroy() {
		this.app.ticker.remove(this.tick);
		this.tweens.destroy();
		this.root.removeChild(this.particles.container);
		this.particles.destroy();
		// textures are owned by the asset loader — destroy display objects only
		this.root.destroy({ children: true, texture: false });
	}
}
